app.factory('test123', function($cookies){

      var get = function(){

          $cookies.remove('cookieNom')
          $cookies.remove('cookieCode')

      };

return{

  get:get
};
})
