app.controller('CalculatorCtrl2', function($scope) {

    $scope.s = {};
    $scope.s.bonjour = "bonjour";
});